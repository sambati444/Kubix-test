export class LineItem {
    quantity: number;
    weight: number;
    dimension: string;
}
