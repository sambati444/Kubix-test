import { Component, OnInit } from '@angular/core';
import { DataService } from './data.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { filter } from 'rxjs/operators';
import { LineItem } from './lineItem';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  locationsCtrl: FormControl;
  locations = [];
  filteredLocations: Observable<any[]>;
  ratesMatching: Observable<any[]>;
  rates: Observable<any[]>;
  lineItem: LineItem = {'quantity': 0, weight: 0, dimension: ''};
  calculatedPrice = '';
  sourceCode = '';
  destinationCode = '';
  rateObj = [];
  resultObj = [];

  constructor(private dataService: DataService ) {
    this.locationsCtrl = new FormControl();
    this.filteredLocations = this.locationsCtrl.valueChanges
      .pipe(
        startWith(''),
        map(location => location ? this.filterLocations(location) : this.locations.slice())
      );
  }

  ngOnInit() {
    this.getLocations();
    this.getRatesMatching();
    this.getRates();
  }
  getLocations() {
    this.dataService.getLocations().subscribe(
      response => this.locations = response.locations
    );
  }

  getRatesMatching() {
    this.dataService.getRatesMatching().subscribe(
      ratesMatching => this.ratesMatching = ratesMatching.rates_matching_criteria
    );
  }

  getRates() {
    this.dataService.getRates().subscribe(
      rates => this.rates = rates.rates
    );
  }

  filterLocations(postal_code: String) {
    return this.locations.filter(location =>
      location.postal_code.toLowerCase().indexOf(postal_code) === 0);
  }

  calculatePrice() {
    let srcRateCode = [];
    let destRateCode = [];
    const sourceCode = this.sourceCode;
    const destinationCode = this.destinationCode;
    const self = this;
    if (sourceCode !== '' && destinationCode !== '' && this.lineItem.quantity > 0 && this.lineItem.weight > 0) {
      srcRateCode = this.ratesMatching.filter(function (item) {
        return item.postal_code === sourceCode;
      });
      destRateCode = this.ratesMatching.filter(function (item) {
        return item.postal_code === destinationCode;
      });
      srcRateCode.forEach(function (item) {
        self.rates.forEach(function (rateItem) {
          if (rateItem.id === item.rate_id) {
            self.rateObj.push(rateItem);
          }
        });
      });
      destRateCode.forEach(function (item) {
        self.rates.forEach(function (rateItem) {
          if (rateItem.id === item.rate_id) {
            self.rateObj.push(rateItem);
          }
        });
      });
      self.rateObj.forEach(function (item) {
        const resultItem: any = {};
        resultItem.carrier_name = item.carrier_name;
        if (item.calculation_type === 'QUANTITY') {
          resultItem.cost = self.lineItem.quantity;
        } else if (item.calculation_type === 'PER_POUND') {
          resultItem.cost = self.lineItem.weight;
        }
        self.resultObj.push(resultItem);
      });
    }
  }
}
