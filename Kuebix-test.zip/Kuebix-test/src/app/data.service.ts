import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private locationsUrl = '../assets/mock-data/locations.json';
  private ratesUrl = '../assets/mock-data/rates.json';
  private rateMatchingUrl = '../assets/mock-data/rate_matching_criteria.json';

  constructor(private http: HttpClient) { }

  getLocations (): Observable<any> {
    return this.http.get<any[]>(this.locationsUrl);
  }
  getRatesMatching (): Observable<any> {
    return this.http.get<any[]>(this.rateMatchingUrl);
  }
  getRates (): Observable<any> {
    return this.http.get<any[]>(this.ratesUrl);
  }
}
